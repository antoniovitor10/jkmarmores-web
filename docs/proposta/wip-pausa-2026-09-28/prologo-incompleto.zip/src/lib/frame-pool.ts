// Cache limitado de quadros decodificados; a animação nunca aguarda a rede.
export function framePool(folder: string, count: number, limit = 8) {
  const ready = new Map<number, HTMLImageElement>();
  const requested = new Set<number>();
  const pending: number[] = [];
  let jobs = 0, disposed = false;
  const pump = () => {
    while (!disposed && jobs < 2 && pending.length) {
      const index = pending.shift()!;
      const img = new Image(); img.decoding = 'async'; img.fetchPriority = 'low';
      jobs++; img.src = `${folder}/${String(index).padStart(2, '0')}.avif`;
      void img.decode().then(() => {
        if (disposed) return;
        ready.set(index, img);
        while (ready.size > limit) { const oldest = ready.keys().next().value!; ready.delete(oldest); requested.delete(oldest); }
      }).catch(() => {}).finally(() => { jobs--; pump(); });
    }
  };
  return {
    prime(index: number) {
      for (const i of [index, index + 1, index - 1]) if (i >= 0 && i < count && !requested.has(i)) { requested.add(i); pending.push(i); }
      pump();
    },
    get(index: number) { return ready.get(index); },
    dispose() { disposed = true; pending.length = 0; ready.clear(); },
  };
}
