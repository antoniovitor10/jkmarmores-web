import type { ReactNode } from "react";
import styles from "./HomeHero.module.css";
import { PrologueArt } from './PrologueArt';
import './Prologue.css';

export function HeroScrub({ children }: { children: ReactNode }) {
  return <div className={`${styles.track} prologue`}>
    <noscript><style>{`.${styles.track}[data-motion] { height:auto; } .${styles.stage} { position:relative; }`}</style></noscript>
    <div className={styles.stage} data-hero-stage>
      {children}
      <PrologueArt />
      <div className={styles.progress} aria-hidden="true" />
    </div>
    <div className="monogram-static">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/brand/jk-monograma-provisorio.svg" width="800" height="500" alt="JK" loading="lazy" />
      <p>Mármores e Granitos</p>
    </div>
  </div>;
}
