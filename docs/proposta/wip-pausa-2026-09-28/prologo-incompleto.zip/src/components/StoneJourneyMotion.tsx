"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { gestureMedia, loadBufferedClip } from "@/lib/gesture-media";
import { motionNetworkPolicy, type MotionConnection } from "@/lib/motion-network";
import type { JourneyVideo } from "@/content/stone-journey";

const clamp = (n: number) => Math.max(0, Math.min(1, n));

export function StoneJourneyMotion({ children, video }: { children: ReactNode; video: JourneyVideo | null }) {
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = root.current;
    if (!el) return;
    // Uma observação para as imagens HTML; sem quatro estados/montagens React.
    // Também funciona no modo estático por preferência ou economia de dados.
    const images = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      el.querySelectorAll<HTMLSourceElement>("[data-journey-image] source").forEach(source => {
        source.srcset = source.dataset.srcset!;
      });
      el.querySelectorAll<HTMLImageElement>("[data-journey-image] img").forEach(image => {
        image.src = image.dataset.src!;
      });
      images.disconnect();
    });
    images.observe(el);
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    const connection = (navigator as Navigator & { connection?: MotionConnection }).connection;
    let dispose = () => {};
    function configure() {
      dispose();
      if (!el) return;
      delete el.dataset.enhanced;
      if (reduced.matches || connection?.saveData) return;
      el.dataset.enhanced = "true";
      const frames = [...el.querySelectorAll<HTMLElement>(".journey-frame")];
      const sticky = el.querySelector<HTMLElement>(".journey-sticky")!;
      let raf = 0;
      let stickyHeight = innerHeight;
      const pictureHeights = new Map<Element, number>();
      const pictures = frames.map(frame => frame.querySelector("picture")!);
      const sizes = new ResizeObserver(entries => {
        for (const entry of entries) {
          if (entry.target === sticky) stickyHeight = entry.borderBoxSize[0]?.blockSize ?? entry.contentRect.height;
          else pictureHeights.set(entry.target, entry.contentRect.height);
        }
        schedule();
      });
      sizes.observe(sticky);
      pictures.forEach(picture => sizes.observe(picture));
      const media: (HTMLVideoElement | null)[] = frames.map(() => null);
      const motions = frames.map((frame, index) => gestureMedia(frame, frame.querySelector("img")!, () => media[index]));
      const mediaSources: string[] = frames.map(() => "");
      const releaseMedia = frames.map(() => () => {});
      let loaded = false;
      let visible = false;
      const failed = new Set<number>();
      let disposed = false;
      const allowMedia = () => {
        // Duas pinturas depois de load: poster e tipografia ja foram apresentados.
        requestAnimationFrame(() => requestAnimationFrame(() => {
          if (!disposed) {
            el!.dataset.mediaPolicy = motionNetworkPolicy(connection);
            loaded = el!.dataset.mediaPolicy === "allowed";
            schedule();
          }
        }));
      };
      function prepareVideo(index: number) {
        if (!video || failed.has(index) || !loaded || !visible || /(^|-)2g|3g/.test(connection?.effectiveType ?? "")) return;
        const clip = video.clips[index];
        if (!clip) return;
        const mobile = innerWidth <= 700;
        const source = mobile ? clip.mobile : clip.desktop;
        if (media[index] && mediaSources[index] !== source.src) {
          motions[index].dispose();
          media[index]!.removeAttribute("src");
          media[index]!.load();
          media[index]!.remove();
          releaseMedia[index]();
          media[index] = null;
          motions[index] = gestureMedia(frames[index], frames[index].querySelector("img")!, () => media[index]);
        }
        if (index === 0 || media[index]) return;
        const totalBytes = video.clips.reduce((sum, item) => sum + (mobile ? item.mobile.bytes : item.desktop.bytes), 0);
        if (totalBytes > (mobile ? 3_000_000 : 8_000_000) || source.bytes <= 0 || clip.durationSeconds <= 0) return;
        const item = document.createElement("video");
        item.muted = true;
        item.playsInline = true;
        item.preload = "auto";
        item.setAttribute("aria-hidden", "true");
        item.className = "journey-video";
        item.poster = frames[index].querySelector("img")?.currentSrc ?? "";
        item.addEventListener("error", () => { failed.add(index); item.remove(); media[index] = null; });
        item.addEventListener("loadeddata", schedule);
        item.addEventListener("seeked", schedule);
        mediaSources[index] = source.src;
        // Cada vídeo pertence ao seu quadro: a transição aprovada continua no figure.
        frames[index].append(item);
        media[index] = item;
        releaseMedia[index] = loadBufferedClip(item, source.src);
      }
      function render() {
        raf = 0;
        // Não mede quatro figuras nem invalida estilos enquanto a seção está fora da tela.
        if (!visible) { motions.forEach(motion => motion?.pause(true)); return; }
        const rect = el!.getBoundingClientRect();
        const travel = Math.max(1, rect.height - stickyHeight);
        // Preserva o trajeto da máscara aprovada; encurta somente os quatro quadros.
        const maskTravel = 0;
        const reveal = 1;
        const story = clamp((-rect.top - maskTravel) / Math.max(1, travel - maskTravel));
        el!.style.setProperty("--mask-scale", String(1 + Math.pow(reveal, 2.4) * 13));
        el!.style.setProperty("--mask-opacity", String(1 - clamp((reveal - .58) / .42)));
        el!.style.setProperty("--mask-copy-opacity", String(1 - clamp(reveal * 4)));
        el!.style.setProperty("--journey-progress", String(story));
        const position = story * 3.65;
        const active = Math.min(3, Math.floor(position + .15));
        frames.forEach((frame, index) => {
          frame.style.setProperty("--frame-opacity", String(index <= active ? 1 : 0));
          frame.dataset.current = String(index === active);
        });
        prepareVideo(active);
        // Aquece só a próxima etapa enquanto a atual está em cena, em rede elegível.
        if (active < 3) prepareVideo(active + 1);
        if (position - active < .15 && active > 0) prepareVideo(active - 1);
        motions.forEach((motion, index) => {
          motion.pause(!visible || document.hidden || reveal < 1 || index !== active);
          motion.to(index <= active && reveal === 1 ? 1 : 0);
          const item = media[index];
          if (!item) return;
          const height = pictureHeights.get(pictures[index]);
          if (height) item.style.height = `${height}px`;
          item.style.bottom = "auto";
          item.style.opacity = reveal === 1 && frames[index].dataset.mediaMode === "video" ? "1" : "0";
        });
      }
      function schedule() { if (!disposed && !raf) raf = requestAnimationFrame(render); }
      const observer = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; if (visible) el.style.setProperty("--mask-image", "url('/img/a1-prova-01-1200.avif')"); schedule(); }, { rootMargin: "0px" });
      observer.observe(el);
      addEventListener("scroll", schedule, { passive: true });
      addEventListener("resize", schedule);
      document.addEventListener("visibilitychange", schedule);
      if (document.readyState === "complete") allowMedia();
      else addEventListener("load", allowMedia, { once: true });
      render();
      dispose = () => {
        disposed = true;
        observer.disconnect();
        sizes.disconnect();
        removeEventListener("scroll", schedule);
        removeEventListener("resize", schedule);
        document.removeEventListener("visibilitychange", schedule);
        motions.forEach(motion => motion?.dispose());
        removeEventListener("load", allowMedia);
        cancelAnimationFrame(raf);
        media.forEach(item => { item?.pause(); item?.removeAttribute("src"); item?.load(); item?.remove(); });
        releaseMedia.forEach(release => release());
        delete el.dataset.enhanced;
        delete el.dataset.mediaPolicy;
        el.removeAttribute("style");
        frames.forEach(frame => { frame.removeAttribute("style"); delete frame.dataset.current; });
      };
    }
    configure();
    reduced.addEventListener("change", configure);
    connection?.addEventListener("change", configure);
    return () => { images.disconnect(); dispose(); reduced.removeEventListener("change", configure); connection?.removeEventListener("change", configure); };
  }, [video]);

  return <div ref={root} className="journey-track" data-enhanced="true">
    <noscript><style>{`
      .journey-frame noscript { display:contents; }
      .journey-track[data-enhanced] { height:auto; contain:none; }
      [data-enhanced] .journey-sticky { position:static; display:block; height:auto; content-visibility:visible; }
      [data-enhanced] .journey-frame { position:static; display:block; opacity:1; }
      [data-enhanced] .journey-frame figcaption { visibility:visible; }
      [data-enhanced] .journey-frame img { height:auto; aspect-ratio:16/9; }
      [data-enhanced] .journey-mask,[data-enhanced] .journey-progress { display:none; }
      @media(max-width:700px) { [data-enhanced] .journey-frame img { aspect-ratio:4/5; } }
    `}</style></noscript>
    {children}
  </div>;
}
