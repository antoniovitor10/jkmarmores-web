import { monogramPaths } from '@/content/monogram';
import { Foto } from './Foto';

export function PrologueArt() {
  return <>
    <svg className="prologue-art" viewBox="0 0 1600 900" aria-hidden="true">
      <defs><clipPath id="jk-prologue-clip" clipPathUnits="userSpaceOnUse"><g className="jk-clip-group">{monogramPaths.map(d => <path key={d} d={d} />)}</g></clipPath></defs>
      <image className="prologue-stone" width="1600" height="900" preserveAspectRatio="none" />
    </svg>
    <canvas className="prologue-canvas" aria-hidden="true" width="1" height="1" />
    <p className="prologue-signature" aria-hidden="true">Mármores e Granitos</p>
    <div className="prologue-cut" aria-hidden="true"><Foto id="jornada-rosada-01" alt="" sizes="100vw" /></div>
  </>;
}
